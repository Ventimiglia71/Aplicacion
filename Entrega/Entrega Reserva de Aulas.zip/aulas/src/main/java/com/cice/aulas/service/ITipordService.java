package com.cice.aulas.service;

import java.util.List;

import com.cice.aulas.entities.TipOrd;

public interface ITipordService {
	public List<TipOrd> allTiposOrdenador();
	public List<TipOrd> findAll();
	
}

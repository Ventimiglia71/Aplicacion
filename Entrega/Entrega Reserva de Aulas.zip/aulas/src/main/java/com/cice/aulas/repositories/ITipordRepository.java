package com.cice.aulas.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cice.aulas.entities.TipOrd;

public interface ITipordRepository extends JpaRepository<TipOrd, Integer> {

}
